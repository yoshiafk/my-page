/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.mypage.agencyportal.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.mypage.agencyportal.service.http.AgentTokenLimiterServiceSoap}.
 *
 * @author Gositus Team
 * @deprecated As of Athanasius (7.3.x), with no direct replacement
 * @generated
 */
@Deprecated
public class AgentTokenLimiterSoap implements Serializable {

	public static AgentTokenLimiterSoap toSoapModel(AgentTokenLimiter model) {
		AgentTokenLimiterSoap soapModel = new AgentTokenLimiterSoap();

		soapModel.setAgentTokenLimiterId(model.getAgentTokenLimiterId());
		soapModel.setGroupId(model.getGroupId());
		soapModel.setCompanyId(model.getCompanyId());
		soapModel.setUserId(model.getUserId());
		soapModel.setUserName(model.getUserName());
		soapModel.setCreateDate(model.getCreateDate());
		soapModel.setModifiedDate(model.getModifiedDate());
		soapModel.setDeptCode(model.getDeptCode());
		soapModel.setToken(model.getToken());
		soapModel.setIsValid(model.getIsValid());
		soapModel.setTokenType(model.getTokenType());

		return soapModel;
	}

	public static AgentTokenLimiterSoap[] toSoapModels(
		AgentTokenLimiter[] models) {

		AgentTokenLimiterSoap[] soapModels =
			new AgentTokenLimiterSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static AgentTokenLimiterSoap[][] toSoapModels(
		AgentTokenLimiter[][] models) {

		AgentTokenLimiterSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels =
				new AgentTokenLimiterSoap[models.length][models[0].length];
		}
		else {
			soapModels = new AgentTokenLimiterSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static AgentTokenLimiterSoap[] toSoapModels(
		List<AgentTokenLimiter> models) {

		List<AgentTokenLimiterSoap> soapModels =
			new ArrayList<AgentTokenLimiterSoap>(models.size());

		for (AgentTokenLimiter model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new AgentTokenLimiterSoap[soapModels.size()]);
	}

	public AgentTokenLimiterSoap() {
	}

	public long getPrimaryKey() {
		return _agentTokenLimiterId;
	}

	public void setPrimaryKey(long pk) {
		setAgentTokenLimiterId(pk);
	}

	public long getAgentTokenLimiterId() {
		return _agentTokenLimiterId;
	}

	public void setAgentTokenLimiterId(long agentTokenLimiterId) {
		_agentTokenLimiterId = agentTokenLimiterId;
	}

	public long getGroupId() {
		return _groupId;
	}

	public void setGroupId(long groupId) {
		_groupId = groupId;
	}

	public long getCompanyId() {
		return _companyId;
	}

	public void setCompanyId(long companyId) {
		_companyId = companyId;
	}

	public long getUserId() {
		return _userId;
	}

	public void setUserId(long userId) {
		_userId = userId;
	}

	public String getUserName() {
		return _userName;
	}

	public void setUserName(String userName) {
		_userName = userName;
	}

	public Date getCreateDate() {
		return _createDate;
	}

	public void setCreateDate(Date createDate) {
		_createDate = createDate;
	}

	public Date getModifiedDate() {
		return _modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;
	}

	public String getDeptCode() {
		return _deptCode;
	}

	public void setDeptCode(String deptCode) {
		_deptCode = deptCode;
	}

	public String getToken() {
		return _token;
	}

	public void setToken(String token) {
		_token = token;
	}

	public int getIsValid() {
		return _isValid;
	}

	public void setIsValid(int isValid) {
		_isValid = isValid;
	}

	public String getTokenType() {
		return _tokenType;
	}

	public void setTokenType(String tokenType) {
		_tokenType = tokenType;
	}

	private long _agentTokenLimiterId;
	private long _groupId;
	private long _companyId;
	private long _userId;
	private String _userName;
	private Date _createDate;
	private Date _modifiedDate;
	private String _deptCode;
	private String _token;
	private int _isValid;
	private String _tokenType;

}