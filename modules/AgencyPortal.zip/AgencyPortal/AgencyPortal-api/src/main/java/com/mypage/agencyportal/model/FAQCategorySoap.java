/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.mypage.agencyportal.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author Gositus Team
 * @deprecated As of Athanasius (7.3.x), with no direct replacement
 * @generated
 */
@Deprecated
public class FAQCategorySoap implements Serializable {

	public static FAQCategorySoap toSoapModel(FAQCategory model) {
		FAQCategorySoap soapModel = new FAQCategorySoap();

		soapModel.setFaqCategoryId(model.getFaqCategoryId());
		soapModel.setCategory(model.getCategory());
		soapModel.setActive(model.getActive());
		soapModel.setGroupId(model.getGroupId());
		soapModel.setCompanyId(model.getCompanyId());
		soapModel.setUserId(model.getUserId());
		soapModel.setUserName(model.getUserName());
		soapModel.setCreateDate(model.getCreateDate());
		soapModel.setModifiedDate(model.getModifiedDate());

		return soapModel;
	}

	public static FAQCategorySoap[] toSoapModels(FAQCategory[] models) {
		FAQCategorySoap[] soapModels = new FAQCategorySoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static FAQCategorySoap[][] toSoapModels(FAQCategory[][] models) {
		FAQCategorySoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new FAQCategorySoap[models.length][models[0].length];
		}
		else {
			soapModels = new FAQCategorySoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static FAQCategorySoap[] toSoapModels(List<FAQCategory> models) {
		List<FAQCategorySoap> soapModels = new ArrayList<FAQCategorySoap>(
			models.size());

		for (FAQCategory model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new FAQCategorySoap[soapModels.size()]);
	}

	public FAQCategorySoap() {
	}

	public long getPrimaryKey() {
		return _faqCategoryId;
	}

	public void setPrimaryKey(long pk) {
		setFaqCategoryId(pk);
	}

	public long getFaqCategoryId() {
		return _faqCategoryId;
	}

	public void setFaqCategoryId(long faqCategoryId) {
		_faqCategoryId = faqCategoryId;
	}

	public String getCategory() {
		return _category;
	}

	public void setCategory(String category) {
		_category = category;
	}

	public int getActive() {
		return _active;
	}

	public void setActive(int active) {
		_active = active;
	}

	public long getGroupId() {
		return _groupId;
	}

	public void setGroupId(long groupId) {
		_groupId = groupId;
	}

	public long getCompanyId() {
		return _companyId;
	}

	public void setCompanyId(long companyId) {
		_companyId = companyId;
	}

	public long getUserId() {
		return _userId;
	}

	public void setUserId(long userId) {
		_userId = userId;
	}

	public String getUserName() {
		return _userName;
	}

	public void setUserName(String userName) {
		_userName = userName;
	}

	public Date getCreateDate() {
		return _createDate;
	}

	public void setCreateDate(Date createDate) {
		_createDate = createDate;
	}

	public Date getModifiedDate() {
		return _modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;
	}

	private long _faqCategoryId;
	private String _category;
	private int _active;
	private long _groupId;
	private long _companyId;
	private long _userId;
	private String _userName;
	private Date _createDate;
	private Date _modifiedDate;

}